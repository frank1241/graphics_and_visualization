1. Open group_14_assignment6.pde in Processing.
2. Click the play button to run.
3. Extra Credit Interactivity:
   Click your mouse button any where on the screen to add additional fish to the scene. 
4. Double click on the movie file and run the movie.mov file with any movie player that supports .mov files.