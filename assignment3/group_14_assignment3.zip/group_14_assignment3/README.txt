How to run extract_words.py:

Run the extract_words.py script using either the command line (python extract_words.py) or pycharm IDE (click play button).

Make sure that the TheVisionOfHell.txt is in the same directory as the python script. 
The result will output three text files 
in the same directory as the script (allwords.txt, uniquewords.txt, and wordfrequency.txt).



How to run a3_novelvisualization.pde:

Make sure that uniquewords.txt is in the same folder as the processing file. 
Open up a3_novelvisualization.pde in processing and click the play button to run the code. 



How to run a3_wordfrequency.pde:

Make sure that wordfrequency.txt is in the same folder as the processing file. 
Open up a3_wordfrequency.pde in processing and click the play button to run the code. 
