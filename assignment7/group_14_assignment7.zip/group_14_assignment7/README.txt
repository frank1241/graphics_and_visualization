1. Open group_14_assignment7.pde in Processing.
2. Click the play button to run.
3. Click once on the screen with your mouse. (Optional, only needed if the spaceship won't respond to your controls) 
4. WASD are the keys to move up, left, down, right. 
5. Press spacebar to shoot the projectile. 
6. Press p to pause and p again to continue. (Extra credit)
7. Press r to restart the game.
8. Double click on the movie file and run the movie.mov file with any movie player that supports .mov files. (Extra Credit)

Troubleshoot:
If the spaceship does not move, try restarting the program and waiting a while. Sometimes it is glitchy. You may need to do this
several times before it works, but it does work.