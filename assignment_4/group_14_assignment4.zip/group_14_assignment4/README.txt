1. Open group_14_assignment4.pde in Processing. Make sure it is in the same folder as all the other files.
1. Install the Minim audio library to Processing. (Sketch --> Import Library --> Select Minim)
2. Click the play button to run.